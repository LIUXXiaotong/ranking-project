
library(tidyverse)
library(afex)
library(rtdists)
library(cowplot)


############### data preparation ###############
### sanitise_ranks function
sanitise_ranks <- function(rank) {
  str_remove_all(rank, "_") %>%
    str_remove_all(" ")
}



### %!in% function
'%!in%' <- function(x, y) !('%in%'(x,y))


### experimental data
dat <- read.csv("clean_data.csv")[, -1]

dl <- dat %>% 
  select(-ends_with("order")) %>% 
  pivot_longer(cols = starts_with("event_set"), names_to = "event", values_to = "response") %>% 
  filter(str_detect(response, "\\d")) %>% 
  mutate(set = str_extract(event, "\\d")) %>% 
  mutate(type = str_remove(event, "event_set\\d_")) %>%
  select(-event)


dl <- dl %>% 
  mutate(response = sanitise_ranks(response))

dl2 <- dat %>% 
  select(ends_with("order")) %>% 
  pivot_longer(cols = starts_with("event_set"), 
               names_to = "event", values_to = "order") %>% 
  filter(!str_detect(order, "-")) %>%
  mutate(set = str_extract(event, "\\d")) %>%  
  select(-event) 


dl <- dl %>% 
  left_join(dl2)


dl <- dl %>% filter(condition == "full")

dl_interest <- dl %>% filter(type == "marginal") %>% select(-order) %>% unique()

############### data analysis  ###############

### coherent formalities
coherence_all <- read.csv("rank1_strict1_strict.csv", check.names=FALSE) 
coherence_all <- coherence_all[-1]
colnames(coherence_all) <- c("marginal", "conunction", "disjunction")
coherence_all <- coherence_all %>% 
  mutate(marginal = sanitise_ranks(marginal),
         conjunction = sanitise_ranks(conunction),
         disjunction = sanitise_ranks(disjunction))

margianl_coherence <- coherence_all$marginal %>% unique()
class_two <- c("1234", "2134", "1243", "2143", "3412", "3421", "4312", "4321")

margianl_coherence


dl_interest <- mutate(dl_interest, logical_err_type = ifelse(response %in% margianl_coherence, 0,
                                                        ifelse(response %in% class_two, 1, 2)))

dl_interest <- mutate(dl_interest, logical_yes = ifelse(response %in% margianl_coherence, 0, 1))

mean(dl_interest$logical_yes)
sd(dl_interest$logical_yes)


D_set <- dl_interest %>% group_by(set) %>%
  mutate(set_mean = mean(logical_err)) %>% select(set, set_mean) %>% unique()


D_individual <- dl_interest %>% group_by(id) %>%
  mutate(mean = mean(logical_err)) %>% select(id, mean) %>% unique()



ggplot(data=D_individual, aes(x=mean)) + 
  geom_bar() + 
  labs(x = "Probabilities of providing logically possible rankings",
       y = "Count") +
  theme_classic2() + 
  theme(axis.title.x = element_text(size=20),
        axis.title.y = element_text(size=20))

